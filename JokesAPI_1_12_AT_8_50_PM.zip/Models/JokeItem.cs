﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JokesAPI.Models
{
    public class JokeItem
    {
        public long Id { get; set; }
        public string Joke { get; set; }

        //TODO: Add other attributes such as Category, Author, DateAdded, DateModified, Language, Rating, etc

    }
}
